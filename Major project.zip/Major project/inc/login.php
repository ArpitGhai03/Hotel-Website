<?php
    include "../admin/inc/db_config.php";
   
    

    if(isset($_POST['login'])){
        $username=$_POST['email'];
        $passowrd=$_POST['password'];
        // echo $username;

        // echo $passowrd;

        $query="select * from user_cred where email='$username' and password ='$passowrd'";
        $result=mysqli_query($con,$query);
        if(mysqli_num_rows($result)>0){
            while($row=mysqli_fetch_assoc($result)){
                
                header("location:../index.php");
                
                
            }
        }
        else{
            // alert("error","wrong password ");
            ?>
            <script src="https://ajax.googleapis.com/ajax/libs/cesiumjs/1.78/Build/Cesium/Cesium.js"></script>
            <script>
                alert("wrong passprd");
                window.location.href'../index.php';
                
            </script>
            <?php
            
        }

    }
    
?>